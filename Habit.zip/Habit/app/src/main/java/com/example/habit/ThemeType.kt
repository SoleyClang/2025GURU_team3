package com.example.habit

enum class ThemeType {
    HEALTH, SELF_DEV, LIFESTYLE
}
